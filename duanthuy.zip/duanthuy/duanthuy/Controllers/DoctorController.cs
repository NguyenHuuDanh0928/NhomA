﻿using Microsoft.AspNetCore.Mvc;
using KoiVeterinaryServiceCenter.Models;
using System.Collections.Generic;
using System.Numerics;
namespace KoiVeterinaryServiceCenter.Controllers
{
    public class DoctorController : Controller
    {
        public IActionResult Index()
        {
            // Tạo danh sách bác sĩ giả lập
            var doctors = new List<Doctor>
            {
                new Doctor { Id = 1, Name = "Dr.Tran Van Tuan", Experience = "5 years", Specialization = "Fish Disease", Rating = 4.5 },
                new Doctor { Id = 2, Name = "Dr.Vo Thi Huynh", Experience = "8 years", Specialization = "Koi Health", Rating = 4.8 }
            };

            // Trả về View cùng với danh sách bác sĩ
            return View(doctors);
        }
    }
}
