﻿namespace duanthuy.Models
{
    public class ServiceBooking
    {
        public string ServiceName { get; set; }
        public string DoctorName { get; set; }
        public DateTime BookingTime { get; set; }
        public double Cost { get; set; }
    }
}
