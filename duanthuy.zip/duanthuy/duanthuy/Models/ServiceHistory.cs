﻿namespace duanthuy.Models
{
    public class ServiceHistory
    {
        public string ServiceName { get; set; }
        public DateTime Date { get; set; }
        public string DoctorName { get; set; }
        public string Status { get; set; }
    }
}
