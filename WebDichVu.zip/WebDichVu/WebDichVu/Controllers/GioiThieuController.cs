﻿using Microsoft.AspNetCore.Mvc;

namespace WebDichVu.Controllers
{
    public class GioiThieuController : Controller
    {
        public IActionResult Index()
        {

            return View();
        }
    }
}
